package com.mybest.myled;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.SelectableChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    ImageButton btnPower; // 전원 버튼
    ImageButton btnRainbow; // 레인보우 버튼
    Button SelectedColor; // 선택된 색상 나타내는 버튼
    TextView currentState; // 현재 색상과 밝기 표시할 텍스트뷰
    ImageView colorPick; // 색상 선택하는 이미지
    byte[] dataList = new byte[5]; // 아두이노로 데이터를 보낼 배열
    SeekBar bar; // 밝기 조절할 시크바
    TextView brightness; // 밝기 표시할 텍스트뷰
    boolean powerOn = false; // 전원이 켜졌는지 여부
    ImageView selectedView;


    static final int REQUEST_ENABLE_BT = 10;
    BluetoothAdapter mBluetoothAdapter;
    int mPairedDeviceCount = 0;
    Set<BluetoothDevice> pairedDevices;
    BluetoothDevice mRemoteDevice;
    BluetoothSocket mSocket;
    OutputStream mOutputStream;
    InputStream mInputStream;

    Thread mWorkerThread;

    // 블루투스 활성화 여부에 따른 결과
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode) {
            case REQUEST_ENABLE_BT: // 요청한 코드가 REQUEST_ENABLE_BT 라면
                if(resultCode==RESULT_OK) { // 허용을 했다면
                    // 블루투스가 활성 상태로 변경됨
                    selectPairedDevice();
                } else if(resultCode==RESULT_CANCELED) { // 취소를 했다면
                    // 블루투스가 비활성 상태임
                    finish(); // 애플리케이션 종료
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // 장치가 블루투스 지원하는지 확인
    void activateBluetooth() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); // 시스템 서비스이기 때문에 이런 식으로 객체를 얻는다.
        // getDefaultAdapter() 메소드는 장치가 블루투스를 지원하지 않으면 null 값을 리턴
        if(mBluetoothAdapter==null) { // 장치가 블루투스 지원하지 않으면
            Toast.makeText(getApplicationContext(), "블루투스를 지원하지 않습니다.", Toast.LENGTH_SHORT).show();
            finish();
        } else { // 장치가 블루투스 지원하면
            // 블루투스가 비활성화 되어있으면 isEnable() 메소드는 false를 반환한다.
            if(!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            } else { // 블루투스를 지원하고 있는 장치가 활성 상태인 경우
                // 블루투스 페어링 된 목록을 보고 연결할 블루투스를 선택한다.
                selectPairedDevice();
            }
        }
    }


    void selectPairedDevice() {
        pairedDevices = mBluetoothAdapter.getBondedDevices(); // getBondedDevices() 를 사용하면 페어링된 장치 집합을 알 수 있다.
        mPairedDeviceCount = pairedDevices.size();

        if(mPairedDeviceCount==0) { // 페어링 된 장치가 없으면
            Toast.makeText(getApplicationContext(), "페어링 된 장치가 없습니다!", Toast.LENGTH_SHORT).show();
            finish();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //AlertDialog 제목 설정
        builder.setTitle("Select device");

        final List<String> listDevices = new ArrayList<String>();
        for(BluetoothDevice device : pairedDevices) {
            listDevices.add(device.getName());
        }
        if(listDevices.size() == 0){
            //no bonded device => searching
            Log.d("Bluetooth", "No bonded device");
        }else {
            Log.d("Bluetooth", "Find bonded device");
            // 취소 항목 추가
            listDevices.add("Cancel");

            final CharSequence[] items = listDevices.toArray(new CharSequence[listDevices.size()]);
            builder.setItems(items, new DialogInterface.OnClickListener() {
                //각 아이템의 click에 따른 listener를 설정
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Dialog dialog_ = (Dialog) dialog;
                    // 연결할 장치를 선택하지 않고 '취소'를 누른 경우
                    if (which == listDevices.size()-1) {
                        Toast.makeText(dialog_.getContext(), "Choose cancel", Toast.LENGTH_SHORT).show();

                    } else {
                        //취소가 아닌 디바이스를 선택한 경우 해당 기기에 연결
                        connectToBluetoothDevice(items[which].toString());
                    }
                }
            });

            builder.setCancelable(false);    // 뒤로 가기 버튼 사용 금지
            AlertDialog alert = builder.create();
            alert.show();   //alert 시작
        }
    }

    BluetoothDevice getDeviceFromBondedList(String name) {
        BluetoothDevice selectedDevice = null;

        for(BluetoothDevice device : pairedDevices) {
            if(name.equals(device.getName())) {
                selectedDevice = device;
                break;
            }
        }
        return selectedDevice;
    }

    @Override
    protected void onDestroy() {
        try{
            mWorkerThread.interrupt();
            mInputStream.close();
            mOutputStream.close();
            mSocket.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    // 사용자가 선택한 이름을 전달받아 해당 기기와 블루투스를 연결한다.
    void connectToBluetoothDevice(String selectedDeviceName) {
        final Handler mHandler = new Handler() {
            public void handleMessage(Message msg) {
                if(msg.what==1) {
                    try{
                        // 소켓으로 데이터 송수신을 위한 스트림 객체 얻는다.
                        mOutputStream = mSocket.getOutputStream();
                        mInputStream = mSocket.getInputStream();

                    } catch(IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "connect error", Toast.LENGTH_SHORT).show();
                    try {
                        mSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        Thread thread = new Thread(new Runnable() {
            public void run() {
                mRemoteDevice = getDeviceFromBondedList(selectedDeviceName); // 페어링된 목록에서 선택한 이름의 블루투스 객체를 받는다.
                // 블루투스 장치와 통신하기 위해선 소켓 생성시 UUID가 필요하다.
                // 중복되지 않는 Unique 식별키를 생성해서 우리가 필요로 하는 uuid를 얻는다.
                UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"); // 블루투스 통신에선 다음 값을 사용한다.

                try {
                    // 블루투스 통신은 소켓을 생성해서 한다. 소켓을 얻기 위해선 createRfcommSocketToServiceRecord() 메소드를 사용한다.
                    // 앞서 얻은 블루투스 객체로 이 메소드를 사용해 블루투스 모듈과 통신할 수 있는 소켓을 생성한다. 매개변수로 uuid를 넣어주어야 한다.
                    mSocket = mRemoteDevice.createRfcommSocketToServiceRecord(uuid);
                    // RFCOMM 채널을 통한 연결, socket에 connect하는데 시간이 걸린다. 따라서 ui에 영향을 주지 않기 위해서는
                    // Thread로 연결 과정을 수행해야 한다.
                    mSocket.connect();
                    mHandler.sendEmptyMessage(1);
                } catch (Exception e) {
                    // 블루투스 연결 중 오류 발생
                    e.printStackTrace();
                    mHandler.sendEmptyMessage(-1);
                }
            }
        });
        //연결 thread를 수행한다
        thread.start();
    }

    // 안드로이드 기기에서는 언제 블루투스로부터 데이터를 수신할지 모르기 때문에 별도의 스레드를 만들어 사용해야 한다.
    // 사용자가 화면을 터치하게 되면 처리하는 메인 스레드와 별도로 블루투스로부터 데이터를 수신하는 스레드를 만들어야 한다.
    // 만약 메인 스레드가 하나만 있다면 메인 스레드가 데이터를 수신하기 위해 기다리고 있기 때문에 사용자가 화면을 터치해도 아무 반응이 일어나지 않는다.
    // 그래서 별도의 데이터를 처리하는 스데르를 만들고 핸들러로 관리하면 된다.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentState = findViewById(R.id.currentState);
        colorPick = (ImageView)findViewById(R.id.colorPick);
        bar = findViewById(R.id.bar);
        brightness = findViewById(R.id.brightness);
        selectedView = findViewById(R.id.selectedView);
        // 초기 색상은 하얀색으로 설정
        dataList[0] = (byte) 255;
        dataList[1] = (byte) 255;
        dataList[2] = (byte) 255;

        // 이미지에서 색상 선택하면 색상 보내기
        colorPick.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                final int evX = (int) event.getX();
                final int evY = (int) event.getY();

                colorPick.setDrawingCacheEnabled(true);
                Bitmap imgbmp = Bitmap.createBitmap(colorPick.getDrawingCache());
                colorPick.setDrawingCacheEnabled(false);

                try {
                    int pixel = imgbmp.getPixel(evX, evY);
                    dataList[0] = (byte) Color.red(pixel);
                    dataList[1] = (byte) Color.green(pixel);
                    dataList[2] = (byte) Color.blue(pixel);
                    dataList[3] = (byte) bar.getProgress();
                    dataList[4] = (byte) 0;
                    SelectedColor.setBackgroundColor(Color.rgb(Color.red(pixel), Color.green(pixel), Color.blue(pixel)));
                    selectedView.setImageDrawable(null);
                    selectedView.setBackgroundColor(Color.rgb(Color.red(pixel), Color.green(pixel), Color.blue(pixel)));
                    sendRGB();
                    powerOn=true;
                }catch (Exception e){
                    e.printStackTrace();
                }
                imgbmp.recycle();
                return true;
            }
        });

        // 선택했었던 색 보여주고 해당 색 불빛 켜기
        SelectedColor = findViewById(R.id.SelectedColor);
        SelectedColor.setOnClickListener(e-> {
            selected();
        });
        // 전원 버튼
        btnPower = findViewById(R.id.btnPower);
        btnPower.setOnClickListener(e-> {
            power();
        });
        // 레인보우 버튼
        btnRainbow = findViewById(R.id.btnRainbow);
        btnRainbow.setOnClickListener(e-> {
            rainbow();
            selectedView.setImageResource(R.drawable.rainbow);
        });

        // 밝기 조절
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentState.setText("R: "+dataList[0]+" G: "+dataList[1]+" B: "+dataList[2]+" 밝기: "+bar.getProgress());
                brightness.setText("밝기: "+progress);
                dataList[3] = (byte) seekBar.getProgress();
                sendRGB();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        activateBluetooth();

    }

    // RGB 값 블루투스로 보내기
    void sendRGB() {
        try {
            mOutputStream.write(dataList);
        } catch(Exception e) {
            e.printStackTrace();
            finish();
        }
        currentState.setText("R: "+dataList[0]+" G: "+dataList[1]+" B: "+dataList[2]+" 밝기: "+bar.getProgress());
    }

    void rainbow() {
        dataList[4] = (byte) 1;
        sendRGB();
        powerOn=true;
    }

    void selected() {
        dataList[4] = (byte) 0;
        sendRGB();
        powerOn=true;
    }

    void power() {
        dataList[4] = 0;
        if(powerOn) {
            bar.setProgress(0);
            dataList[3] = (byte) bar.getProgress();
            sendRGB();
            powerOn=false;
        }
        else if(powerOn == false) {
            bar.setProgress(255);
            sendRGB();
            powerOn=true;
        }
    }


}